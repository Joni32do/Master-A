#!/usr/bin/env python3

# MIT license
#
# Copyright © 2022-2024 Timo Koch, Martin Schneider
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the “Software”), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

import numpy as np
from scipy.optimize import newton

from pvdwriter import PVDWriter
from mesh import SegmentMesh, BifurcationMesh
from bifurcationsolver import solve_bifurcation

def flux(A, Q, c0, A0):
    """
    The flux function of the transport equation F = (F1, F2)
    Return a tuple (F1, F2)
    """
    ...


def characteristic_variables(A, Q, c0, A0):
    """
    Transform A and Q into the characteristic variables W1 and W2
    Return a tuple (W1, W2)
    """
    ...


def primary_variables(W1, W2, c0, A0):
    """
    Transform W1 and W2 back to A and Q
    Return a tuple (A, Q)
    """
    ...


def Q_inflow(t, Q_max, T_s):
    """The sinusoidal inflow profile evaluated at time t"""
    return Q_max * np.sin(t * np.pi / T_s)


def W2_inflow(W1, Q, c0, A0, W2_initial_guess):
    """
    Use a Newton solver to compute W2 from W1 and Q
    At the inflow, we know W1 and Q (input to this function)
    The equation that relates Q, W1 and W2 (see primary_variables)
    can be solved for W2. Bring this equation in the form: func(W2) = 0.
    """

    def func(W2):
        ...

    def fprime(W2):
        """
        Return dfunc/dW2
        Alternatively: Have a look a the signature of scipy.optimize.newton:
        It can approximate the Jacobian for you (less accurate)
        """
        ...

    return newton(
        func=func, x0=W2_initial_guess, fprime=fprime, tol=1.0e-11, maxiter=35
    )


def writeOutput(i, n=200):
    """Return true every n time steps"""
    return i % n == 0

# physical parameters
# (we take these as constants for all vessels)
h0 = 0.16  # wall thickness (cm)
E = 0.4e4  # elasticity (kg/(cm*s^2))
nu = 0.49  # Poisson ratio (-)
rho = 1.028e-3  # blood density (kg/cm^3)
mu = 4.0e-5  # (dynamic) blood viscosity Pa*s*(cm/m)
Q_max = 185.0  # maximum inflow rate (cm^3/s) # 485
T_s = 0.3  # time for systole (s)
T_d = 1.0  # time of one heartbeat
p_to_mmHg = 100*0.0075 # conversion factor to mmHg

# computational domain and mesh
mesh = SegmentMesh(num_cells=50, radius=np.sqrt(1.0/np.pi), length=7.0)
#mesh = BifurcationMesh()

# computed parameters (do not change these manually!)
R0 = mesh.R0() # radius for each element in the mesh
A0 = np.pi * R0**2  # cross-sectional area
G0 = np.sqrt(np.pi) * E * h0 * (1.0 - nu ** 2) * np.sqrt(A0)  # elasticity
KR = 22.0 * np.pi * mu / rho  # friction
c0 = np.sqrt(G0 / (2 * rho))  # characteristic wave speed (m/s)

# numerical parameters (time)
t_start = 0.0
dt = 1.0e-4
t_end = 2  # Simulation period (s)

# array of unknowns (old time step)
# we have A and Q for each cell
A_old = A0
Q_old = np.zeros_like(A0)

# array of unknowns (new/current time step)
A_new = A_old
Q_new = Q_old

# compute initial characteristic variables (used for the boundary conditions)
W1_init, W2_init = characteristic_variables(A=A_old, Q=Q_old, c0=c0, A0=A0)

# output writer
pvd_writer = PVDWriter("vessel", mesh)
pvd_writer.write(0.0, fields={"Q": Q_old, "R": np.sqrt(A_old/np.pi), "p": p_to_mmHg*G0*(np.sqrt(A_old/A0) - 1)})

# time loop
time_points = np.linspace(dt, t_end, int(np.floor(t_end / dt)))
for time_step, t_new in enumerate(time_points):
    t_old = t_new - dt

    # (1) Transform physical variables to characteristic variables for each element
    W1, W2 = ...

    # (2) Incorporate boundary conditions
    # At inflow (left) we need to prescribe the "inflowing" characteristic W2 --->
    # At outflow (right) we need to prescribe the "inflowing" characteristic W1 <---
    # We need to prescribe only the information coming from outside our domain

    # Inflow: Periodic heart beat (half a sine)
    # -----------------------------------------
    # We prescribe the inflow flux Q_in and take
    # the W1 characteristic from the domain, i.e. W1[0] <--- (upwind scheme)
    # We can then solve for the inflowing characteristic variable W2 --->
    timeInPeriod = t_old % T_d
    if timeInPeriod < T_s:
        Q_in = Q_inflow(timeInPeriod, Q_max, T_s)
        W2_in = W2_inflow(
            W1=mesh.inflow_cell_value(W1), Q=Q_in,
            c0=mesh.inflow_cell_value(c0), A0=mesh.inflow_cell_value(A0),
            W2_initial_guess=mesh.inflow_cell_value(W2_init)
        )
    else:  # Q_in = 0 => W1==W2 (simplification/optimization)
        W2_in = mesh.inflow_cell_value(W1)

    # Outflow: Reflection boundary condition
    # --------------------------------------
    # We introduce a non-dimensional reflection coefficient R (0 <= R <= 1)
    # --> R = 1 means full reflection, i.e. zero outflow Q_out = 0
    # --> R = 0 means no reflection, i.e. free outflow
    # Free outflow is achieved by fixing the
    # inflowing W1 (<---) to its initial value i.e. W1(Q=0, A=A0)
    # Vary R between 0 and 1 to see its influence
    # W2 (--->) is taken from the last domain cell (upwind scheme)
    R = 0.2
    W1_out = R * (mesh.outflow_cell_value(W2) - mesh.outflow_cell_value(W1_init)) + mesh.outflow_cell_value(W1_init)

    # (3) Upwind scheme
    # upwind scheme at faces (|): take W1 (<---) from the right and W2 (--->) from the left
    # because we have more faces than cells we need to supply values at the boundary
    # Remark: at bifurcations this operation is not necessarily unique
    # the function here ignores bifurcations (sets W1=W2=0 at bifurcation faces)
    # we will deal with bifurcations below because it is more complicated than a simple upwind scheme
    W1_face = mesh.cell_to_face_take_right(W1, outflow=W1_out)
    W2_face = mesh.cell_to_face_take_left(W2, inflow=W2_in)

    # compute A^* and Q^* for all boundary and inner
    c0_face = mesh.cell_to_face_extend_param(c0)
    A0_face = mesh.cell_to_face_extend_param(A0)
    A_face, Q_face = ... # compute primary variables at the face

    # (4) Bifurcation solver
    # if the mesh has bifurcations compute A_face and Q_face
    # at bifurcations using the bifurcation solver
    if mesh.num_bifurcations > 0:
        for i in range(mesh.num_bifurcations):
            AA, QQ, cc0, AA0 = (
                mesh.bifurcation_cell_value(i, A_old),
                mesh.bifurcation_cell_value(i, Q_old),
                mesh.bifurcation_cell_value(i, c0),
                mesh.bifurcation_cell_value(i, A0),
            )
            A_bifu, Q_bifu = solve_bifurcation(A=AA, Q=QQ, c0=cc0, A0=AA0)
            mesh.set_face_value_at_bifurcation(i, A_face, value=A_bifu)
            mesh.set_face_value_at_bifurcation(i, Q_face, value=Q_bifu)

    # (5) Compute fluxes
    F1, F2 = ... # compute fluxes at the face

    # compute momentum source term (mass source term is zero)
    S2 = KR * Q_old / A_old

    # (6) Finite volume update (explicit Euler)
    dz = mesh.length()
    F1_left, F1_right = mesh.face_to_cell_take_left(F1), mesh.face_to_cell_take_right(F1)
    F2_left, F2_right = mesh.face_to_cell_take_left(F2), mesh.face_to_cell_take_right(F2)
    A_new = A_old - dt / dz * (F1_right - F1_left)
    Q_new = Q_old - dt / dz * (F2_right - F2_left) - dt * S2

    # update plot
    if writeOutput(time_step):
        print(f"Time step {time_step} done.")
        pvd_writer.write(t_new, fields={"Q": Q_new, "R": np.sqrt(A_new/np.pi), "p": p_to_mmHg*G0*(np.sqrt(A_new/A0) - 1)})

    # update old solution in preparation for next time step
    A_old = A_new
    Q_old = Q_new
