# MIT license
#
# Copyright © 2023 Timo Koch
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the “Software”), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

import xml.etree.ElementTree as xml
from copy import deepcopy

class PVDWriter():
    """
    Initialize like this:
        pvd_writer = PVDWriter("vessel", mesh)
    Example: write out field Q at time t=2.3:
        pvd_writer.write(2.3, fields={"Q": Q})
    Output: There will be a vessel.pvd file
        and a bunch of vessel-<num>.vtp files
        for each written time step. Open the
        pvd file in ParaView to view the time series

    Remark: the initial radius R0 is stored in the mesh and
    gets written out automatically.
    """
    def __init__(self, filename, mesh):
        self.filename = filename
        self.pvd = self._create_new_pvd_template()
        self.vtp = self._create_new_vtp_template(mesh)
        self.num_steps = 0

    def write(self, time, fields=None):
        """Write fields and mesh at given time"""
        pvd_name = f"{self.filename}.pvd"
        vtp_name = f"{self.filename}-{self.num_steps:05}.vtp"

        # add new data set
        collection = self.pvd.find("./Collection")
        data_set = xml.SubElement(
            collection, "DataSet",
            timestep=f"{self.num_steps}",
            group="", part="0", name="",
            file=vtp_name,
        )

        # write pvd file
        pvd_tree = xml.ElementTree(element=self.pvd)
        xml.indent(pvd_tree, "  ")
        pvd_tree.write(pvd_name)

        # add cell data to vtp template
        vtp = deepcopy(self.vtp)
        if fields is not None:
            cell_data = vtp.find("./PolyData/Piece/CellData")
            for name, data in fields.items():
                if len(data) != self.num_cells:
                    raise ValueError(f"Field {name} does not have the right size!")
                self._add_cell_data(cell_data, name, data)

        # write vtp file
        vtp_tree = xml.ElementTree(element=vtp)
        xml.indent(vtp_tree, "  ")
        vtp_tree.write(vtp_name)

        # increase output step counter
        self.num_steps = self.num_steps + 1


    def _create_new_pvd_template(self):
        vtk_file = xml.Element("VTKFile", type="Collection", version="0.1", byte_order="LittleEndian")
        xml.SubElement(vtk_file, "Collection")
        return vtk_file


    def _create_new_vtp_template(self, mesh):
        segments = mesh.as_line_segments()
        vtk_file = xml.Element("VTKFile", type="PolyData", version="0.1", byte_order="LittleEndian")
        poly_data = xml.SubElement(vtk_file, "PolyData")

        # write it as discontinuous data (DG0) so we don't get interpolation effects when using CellToPointData
        self.num_cells = len(segments)
        piece = xml.SubElement(poly_data, "Piece", NumberOfLines=str(self.num_cells), NumberOfPoints=str(2*self.num_cells))
        points = xml.SubElement(piece, "Points")
        points_array = xml.SubElement(points, "DataArray", type="Float32", Name="Coordinates", NumberOfComponents="3", format="ascii")
        points_array.text = " ".join(f"{c}" for s in segments for v in s for c in v)

        lines = xml.SubElement(piece, "Lines")
        cell_array = xml.SubElement(lines, "DataArray", type="Int32", Name="connectivity", NumberOfComponents="1", format="ascii")
        cell_array.text = " ".join(f"{i} {i+1}" for i in range(0, 2*self.num_cells, 2))
        offset_array = xml.SubElement(lines, "DataArray", type="Int32", Name="offsets", NumberOfComponents="1", format="ascii")
        offset_array.text = " ".join(f"{2*(i+1)}" for i in range(0, self.num_cells))

        cell_data = xml.SubElement(piece, "CellData", Scalars="R0")
        self._add_cell_data(cell_data, "R0", mesh.R0())

        return vtk_file


    def _add_cell_data(self, node, name, data):
        data_array = xml.SubElement(
            node, "DataArray", type="Float32",
            Name=f"{name}", NumberOfComponents="1", format="ascii",
        )
        data_array.text = " ".join(f"{d}" for d in data)


def _test_output():
    """Small test for debugging"""
    from mesh import BifurcationMesh
    m = BifurcationMesh()
    pvd_writer = PVDWriter("test", m)
    pvd_writer.write(time=0.0)
    pvd_writer.write(time=1.0)


if __name__ == "__main__":
    # run test if this is executed as a standalone script
    _test_output()
