# MIT license
#
# Copyright © 2023 Timo Koch
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the “Software”), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

"""Meshes for the vessel exercise"""

import numpy as np

class SegmentMesh():
    """
    A simple mesh consisting of a single segment without bifurcations
    Coordinates are in centimeter
    """
    def __init__(self, *, num_cells=50, radius=np.sqrt(1.0 / np.pi), length=7.0):
        segment = ([0.0, 0.0, 0.0], [length, 0.0, 0.0])
        self._num_cells = num_cells
        self._begin = np.array(segment[0])
        self._end = np.array(segment[1])
        self._radius = np.ones(self._num_cells) * radius
        self._length = length/float(num_cells)
        self.num_bifurcations = 0

    def R0(self):
        """Returns an array of radii for each element"""
        return self._radius

    def length(self):
        """Returns an array of lengths for each element"""
        return self._length

    def as_line_segments(self):
        """For the output module represent mesh as line segments. Each line segment is a vertex pair."""
        direction = self._end - self._begin
        vertex_pos = np.linspace(0.0, 1.0, self._num_cells+1, endpoint=True)
        return [
            (self._begin + direction*vertex_pos[i], self._begin + direction*vertex_pos[i+1])
            for i in range(self._num_cells)
        ]

    def cell_to_face_extend_param(self, cell_array):
        """Map parameter that is constant per vessel"""
        face_array = np.zeros(len(cell_array) + 1)
        face_array[1:] = cell_array
        face_array[0] = cell_array[0]
        return face_array

    def cell_to_face_take_right(self, cell_array, outflow):
        """At each face take the value of the right neighbor cell"""
        face_array = np.zeros(len(cell_array) + 1)
        face_array[:-1] = cell_array
        face_array[-1] = outflow
        return face_array

    def cell_to_face_take_left(self, cell_array, inflow):
        """At each face take the value of the left neighbor cell"""
        face_array = np.zeros(len(cell_array) + 1)
        face_array[1:] = cell_array
        face_array[0] = inflow
        return face_array

    def face_to_cell_take_left(self, face_array):
        return face_array[:-1]

    def face_to_cell_take_right(self, face_array):
        return face_array[1:]

    def inflow_cell_value(self, cell_array):
        return cell_array[0]

    def outflow_cell_value(self, cell_array):
        return cell_array[-1]

    def make_cell_array(self):
        return np.zeros(self._num_cells)

    def make_face_array(self):
        return np.zeros(self._num_cells + 1)


class BifurcationMesh():
    """
    A mesh consisting of a several bifurcating segments with one inlet and four outlets
    Coordinates are in centimeter
    """
    def _init_vessels(self):
        self._points = np.array([
            [-4.0, 0.0, 13.0], [7.0, 0.0, 0.0],
            [12.0, 3.0, 1.0], [12.0, -3.0, -1.0],
            [18.0, 6.0, 9.0], [18.0, 0.0, 3.0],
            [18.0, -7.0, -2.0], [12.0, -8.0, -8.0],
        ])

        self._segments = [
            (0, 1), (1, 2), (1, 3),
            (2, 4), (2, 5), (3, 6), (3, 7),
        ]

        self._inlet_segments = [0,]
        self._outlet_segments = [3, 4, 5, 6]

        R00 = np.sqrt(1.0/np.pi)
        R01 = np.cbrt(0.5*R00**3) # Murray's law
        R02 = np.cbrt(0.5*R01**3) # Murray's law
        self._radius_per_segment = [
            R00, R01, R01,
            R02, R02, R02, R02,
        ]

        self.num_bifurcations = 3
        self._bifurcations = [[0, 1, 2], [1, 3, 4], [2, 5, 6]]


    def __init__(self, max_element_size=7.0/30):
        # define mesh a set of vessel segments
        self._init_vessels()

        # make mesh elements
        self._num_cells_per_segment = [
            int(np.ceil(np.linalg.norm(self._points[j]-self._points[i])/max_element_size))
            for i, j in self._segments
        ]

        self._num_faces_per_segment = [n+1 for n in self._num_cells_per_segment]

        self._cell_size_per_segment = [
            np.linalg.norm(self._points[j]-self._points[i])/self._num_cells_per_segment[n]
            for n, (i, j) in enumerate(self._segments)
        ]

        self._cell_offset = np.array([
            int(np.sum(self._num_cells_per_segment[0:i]))
            for i in range(len(self._segments)+1)
        ])

        self._face_offset = np.array([
            int(np.sum(self._num_faces_per_segment[0:i]))
            for i in range(len(self._segments)+1)
        ])

        self._num_cells = self._cell_offset[-1]

        self._radius = np.concatenate([
            np.ones(self._num_cells_per_segment[i])*self._radius_per_segment[i]
            for i in range(len(self._segments))
        ])

        self._length = np.concatenate([
            np.ones(self._num_cells_per_segment[i])*self._cell_size_per_segment[i]
            for i in range(len(self._segments))
        ])

        # boundary and bifurcation index sets
        self._inflow_cell_value_indices = [i for i in self._cell_offset[self._inlet_segments]]
        self._outflow_cell_value_indices = [i-1 for i in self._cell_offset[[i+1 for i in self._outlet_segments]]]
        self._inflow_face_value_indices = [i for i in self._face_offset[self._inlet_segments]]
        self._outflow_face_value_indices = [i-1 for i in self._face_offset[[i+1 for i in self._outlet_segments]]]
        self._segment_begin_face_indices = self._face_offset[:-1]
        self._segment_end_face_indices = [i-1 for i in self._face_offset[1:]]


    def R0(self):
        """Returns an array of radii for each element"""
        return self._radius

    def length(self):
        """Returns an array of lengths for each element"""
        return self._length

    def as_line_segments(self):
        """For the output module represent mesh as line segments. Each line segment is a vertex pair."""
        direction = [self._points[j] - self._points[i] for i, j in self._segments]
        return [
            (self._points[i] + direction[n]*s0, self._points[i] + direction[n]*s1)
            for n, (i, _) in enumerate(self._segments)
            for s0, s1 in zip(
                np.linspace(0.0, 1.0, self._num_cells_per_segment[n]+1, endpoint=True)[:-1],
                np.linspace(0.0, 1.0, self._num_cells_per_segment[n]+1, endpoint=True)[1:]
            )
        ]

    def cell_to_face_extend_param(self, cell_array):
        """Map parameters that are constant per vessel from cell to face"""
        face_array = np.zeros(len(cell_array) + len(self._segments))
        for n in range(len(self._segments)):
            face_array[self._face_offset[n]:self._face_offset[n+1]-1] = cell_array[self._cell_offset[n]:self._cell_offset[n+1]]
            face_array[self._face_offset[n+1]-1] = face_array[self._face_offset[n+1]-2]
        return face_array

    def cell_to_face_take_right(self, cell_array, outflow):
        """At each face take the value of the right neighbor cell"""
        face_array = np.zeros(len(cell_array) + len(self._segments))
        for n in range(len(self._segments)):
            face_array[self._face_offset[n]:self._face_offset[n+1]-1] = cell_array[self._cell_offset[n]:self._cell_offset[n+1]]
            face_array[self._face_offset[n+1]-1] = 0.0
        face_array[self._outflow_face_value_indices] = outflow
        return face_array

    def cell_to_face_take_left(self, cell_array, inflow):
        """At each face take the value of the left neighbor cell"""
        face_array = np.zeros(len(cell_array) + len(self._segments))
        for n in range(len(self._segments)):
            face_array[self._face_offset[n]+1:self._face_offset[n+1]] = cell_array[self._cell_offset[n]:self._cell_offset[n+1]]
            face_array[self._face_offset[n]] = 0.0
        face_array[self._inflow_face_value_indices] = inflow
        return face_array

    def face_to_cell_take_left(self, face_array):
        # np.delete picks all entries except the specified ones
        return np.delete(face_array, self._segment_end_face_indices)

    def face_to_cell_take_right(self, face_array):
        # np.delete picks all entries except the specified ones
        return np.delete(face_array, self._segment_begin_face_indices)

    def inflow_cell_value(self, cell_array):
        return cell_array[self._inflow_cell_value_indices]

    def outflow_cell_value(self, cell_array):
        return cell_array[self._outflow_cell_value_indices]

    def make_cell_array(self):
        return np.zeros(self._num_cells)

    def make_face_array(self):
        return np.zeros(self._num_cells + len(self._segments))

    def bifurcation_cell_value(self, id, cell_array):
        in0, out0, out1 = self._bifurcations[id]
        return cell_array[[
            self._cell_offset[in0+1]-1,
            self._cell_offset[out0],
            self._cell_offset[out1]
        ]]

    def set_face_value_at_bifurcation(self, id, face_array, value):
        in0, out0, out1 = self._bifurcations[id]
        face_array[[
            self._face_offset[in0+1]-1,
            self._face_offset[out0],
            self._face_offset[out1]
        ]] = value
