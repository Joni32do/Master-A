# MIT license
#
# Copyright © 2023 Timo Koch
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the “Software”), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

import numpy as np
from scipy.optimize import root

def solve_bifurcation(A, Q, c0, A0):
    """
    Returns A and Q at the bifurcation for each neighboring vessel

    The parameters need to be supplied as a triple (in0, out0, out1)
    where the first parameter belongs to the inflow cell and the
    two following parameters to the two outflow cells. This means
    this bifurcation solver assumes to always have one inflow vessel
    that bifurcates into two outflow vessels.
    It also assumes as orientation that the inflow vessel ends at the
    bifurcation and the outflow vessel start at the bifurcation. This
    determines the sign of some of the terms.
    """

    # characteristic variables for incoming information
    # upwind scheme: take the characteristic variable W2 ---> from the inflow side
    # and the characteristic variable W1 <--- from the outflow sides
    W_in = [
        Q[0] / A[0] + 4 * c0[0] * (A[0] / A0[0]) ** (1.0 / 4.0),
        -Q[1] / A[1] + 4 * c0[1] * (A[1] / A0[1]) ** (1.0 / 4.0),
        -Q[2] / A[2] + 4 * c0[2] * (A[2] / A0[2]) ** (1.0 / 4.0),
    ]

    # the residual function (a residual is a function that is zero at the solution)
    # any equation can be written as a residual function by putting all terms on one side
    def residual(U):
        A_bifu, Q_bifu = U[0:3], U[3:]

        # characteristic variables (outgoing information; coming from the bifurcation)
        W_out = [
            -Q_bifu[0] / A_bifu[0] + 4 * c0[0] * (A_bifu[0] / A0[0]) ** (1.0 / 4.0),
            +Q_bifu[1] / A_bifu[1] + 4 * c0[1] * (A_bifu[1] / A0[1]) ** (1.0 / 4.0),
            +Q_bifu[2] / A_bifu[2] + 4 * c0[2] * (A_bifu[2] / A0[2]) ** (1.0 / 4.0),
        ]

        # total pressure (divided by density)
        p_total_per_density = 0.5*(Q_bifu/A_bifu)**2 + 2*c0**2*( ((A_bifu/A0) ** (1.0/2.0)) - 1)

        # The residual has six entries / consists of six equations
        # --> For each vessel a functional relationship between A, Q, W1, W2, where W1 and W2 are to be replaced
        #     by the appropriate W_in or W_out
        # --> The mass balance equation
        # --> Two equations for the continuity of the total pressure
        return [
            ...
        ]

    # initial guess, take the neighboring cell values
    U_init = np.concatenate([A, Q])

    # solve for root
    result = root(fun=residual, x0=U_init)
    if not result.success:
        RuntimeError("Bifurcation solver did not converge!")

    return result.x[0:3], result.x[3:]
